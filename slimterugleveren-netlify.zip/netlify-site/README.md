# SlimTerugleveren.nl — Deploy Guide

## Bestanden in deze map

```
netlify-site/
├── index.html        ← Hoofdpagina (alles-in-één: HTML + CSS + JS)
├── privacy.html      ← Privacy- en cookiebeleid
├── 404.html          ← Custom 404 pagina
├── netlify.toml      ← Netlify configuratie (headers, redirects, caching)
├── robots.txt        ← Zoekmachine crawl-instructies
├── sitemap.xml       ← XML sitemap voor Google
├── og-image.png      ← Social media preview afbeelding (1200×630)
├── og-image.svg      ← Bronbestand OG-image (kan later vervangen)
└── README.md         ← Dit bestand
```

## Deployen op Netlify (5 minuten)

### Stap 1 — Account aanmaken
1. Ga naar https://app.netlify.com/signup
2. Registreer met e-mail of GitHub

### Stap 2 — Site deployen
1. Log in op Netlify
2. Ga naar "Sites" → klik op "Add new site" → "Deploy manually"
3. Sleep de hele `netlify-site` map naar het upload-veld
4. Klaar! Je krijgt een URL zoals `random-naam.netlify.app`

### Stap 3 — Eigen domein koppelen
1. Koop `slimterugleveren.nl` bij een registrar (bijv. TransIP, Antagonist, Versio)
   - TransIP: https://www.transip.nl/domeinregistratie/
   - Prijs: ~€8-12/jaar voor .nl
2. In Netlify: ga naar Site settings → Domain management → Add custom domain
3. Voer `slimterugleveren.nl` in
4. Netlify toont DNS-instellingen. Stel bij je registrar in:
   - Optie A (aanbevolen): Gebruik Netlify DNS — verander nameservers naar de Netlify NS-records
   - Optie B: Voeg een CNAME record toe: `www` → `jouw-site.netlify.app`
     en een ALIAS/ANAME record voor het apex domain
5. SSL/HTTPS wordt automatisch ingeschakeld (Let's Encrypt)

## Na deployment — Checklist

### ⚠️ VERPLICHT voor je live gaat:

- [ ] **Affiliate links invullen** — Vervang alle `href="#"` placeholder links:
  - PowerPeers: aanmelden via Daisycon (https://daisycon.com) → zoek "PowerPeers" of "Vattenfall"
  - Coolblue Energie: aanmelden via Awin (https://www.awin.com) → zoek "Coolblue Energie"
  - Thuisbatterij: overweeg Zendure (8%), EcoFlow (5%), of Coolblue
  - Laadpalen: Coolblue Energie affiliate of Solvari (via TradeTracker)
  
- [ ] **Privacy pagina invullen** — Open `privacy.html` en vervang:
  - `[jouw naam of bedrijfsnaam]`
  - `[plaats]`
  - `[e-mailadres]`
  - `[Google Analytics / Plausible Analytics]` → kies er één

- [ ] **Analytics instellen** — Open `index.html`, zoek de functie `loadAnalytics()`:
  - Plausible (privacy-friendly, €9/maand): uncomment de Plausible sectie
  - Google Analytics 4 (gratis): uncomment de GA4 sectie, vervang `G-XXXXXXXXXX`

### Aanbevolen:

- [ ] **OG-image vervangen** — Vervang `og-image.png` door een professionelere afbeelding (1200×630px)
- [ ] **Google Search Console** — Claim je site op https://search.google.com/search-console en submit je sitemap
- [ ] **Test deellinks** — Deel je URL op WhatsApp/LinkedIn/Twitter om de preview te controleren

## Domein opties

| Domein | Beschikbaarheid | Geschatte prijs |
|--------|----------------|-----------------|
| slimterugleveren.nl | Controleer bij TransIP | ~€8/jaar |
| slimterugleveren.com | Controleer | ~€12/jaar |
| slim-terugleveren.nl | Alternatief | ~€8/jaar |

## Technische details

- **Hosting**: Netlify Free tier (100GB bandbreedte/maand, ruim genoeg)
- **SSL**: Automatisch via Let's Encrypt
- **CDN**: Netlify Edge (wereldwijd)
- **Framework**: Geen — pure HTML/CSS/JS, geen build stap nodig
- **Performance**: Site is ~65KB, laadt in <1 seconde
